package com.example.moviesapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.preference.PreferenceManager;

import com.bumptech.glide.Glide;
import com.github.ivbaranov.mfb.MaterialFavoriteButton;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.snackbar.Snackbar;

public class TVShowDetailActivity extends AppCompatActivity {
    TextView nameOfShow,plotSynopsis,userRating,releaseDate;
    ImageView imageView;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tvshow_detail);
        Toolbar toolbar=findViewById(R.id.toolbar2);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initCollapsingToolbar();

        imageView=findViewById(R.id.detail_activity_center_image_picture);
        nameOfShow=findViewById(R.id.title);
        plotSynopsis=findViewById(R.id.plot_synopsis);
        userRating=findViewById(R.id.user_rating);
        releaseDate=findViewById(R.id.release_date);
        Intent intentThatStartedThisActivity=getIntent();
        if (intentThatStartedThisActivity.hasExtra("original_name")) {
            String thumbnail = getIntent().getExtras().getString("poster_path");
            String showName = getIntent().getExtras().getString("original_name");
            String synopsis = getIntent().getExtras().getString("overview");
            String rating = getIntent().getExtras().getString("vote_average");
            String dateOfRelease = getIntent().getExtras().getString("first_air_date");


            Glide.with(this).load(thumbnail).placeholder(R.drawable.load).into(imageView);

            nameOfShow.setText(showName);
            plotSynopsis.setText(synopsis);
            userRating.setText(rating);
            releaseDate.setText(dateOfRelease);
        }
        else
        {
            Toast.makeText(this,"No API Data",Toast.LENGTH_SHORT).show();
        }

        MaterialFavoriteButton materialFavoriteButton;
        materialFavoriteButton=findViewById(R.id.favorite_button);
        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        materialFavoriteButton.setOnFavoriteChangeListener(new MaterialFavoriteButton.OnFavoriteChangeListener() {
            @Override
            public void onFavoriteChanged(MaterialFavoriteButton buttonView, boolean favorite) {
                if (favorite) {
                    SharedPreferences.Editor editor = getSharedPreferences("com.example.moviesapp.TVShowDetailActivity", MODE_PRIVATE).edit();
                    editor.putBoolean("Favorite Added ",true);
                    editor.commit();
                    Snackbar.make(buttonView,"Added to Favorite",Snackbar.LENGTH_SHORT).show();;

                }else{
                    SharedPreferences.Editor editor = getSharedPreferences("com.example.moviesapp.TVShowDetailActivity", MODE_PRIVATE).edit();
                    editor.putBoolean("Favorite Removed ",true);
                    editor.commit();
                    Snackbar.make(buttonView,"Removed from Favorite",Snackbar.LENGTH_SHORT).show();
                }

            }
        });


    }
    private  void  initCollapsingToolbar(){
        final CollapsingToolbarLayout collapsingToolbarLayout=findViewById(R.id.collapsingToolBar1);
        collapsingToolbarLayout.setTitle(" ");

        AppBarLayout appBarLayout=findViewById(R.id.appbar1);
        appBarLayout.setExpanded(true);

        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow=false;
            int scrollRange=-1;
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffSet) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                if (scrollRange + verticalOffSet == 0) {
                    collapsingToolbarLayout.setTitle(getString(R.string.tvshow_detail));
                    isShow = true;
                }else  if (isShow){
                    collapsingToolbarLayout.setTitle(" ");
                    isShow=false;
                }

            }
        });
    }

}
