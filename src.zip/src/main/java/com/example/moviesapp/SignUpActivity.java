package com.example.moviesapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignUpActivity extends AppCompatActivity {

    TextInputLayout nameTextInputLayout, emailTextInputLayout,passwordTextInputLayout;
    EditText nameEditText,passwordEditText,emailEditText;
    AppCompatButton mAppCompatButton;
    FirebaseAuth mFirebaseAuth;
    FirebaseUser mFirebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        nameTextInputLayout=findViewById(R.id.nameTextInputLayout);
        emailTextInputLayout=findViewById(R.id.emailTextInputLayout);
        passwordTextInputLayout=findViewById(R.id.passwordTextInputLayout);
        nameEditText=findViewById(R.id.nameEditTextView);
        emailEditText=findViewById(R.id.emailEditTextView);
        passwordEditText=findViewById(R.id.passwordEditText);

        mFirebaseAuth=FirebaseAuth.getInstance();
        mFirebaseUser=mFirebaseAuth.getCurrentUser();

        mAppCompatButton=findViewById(R.id.signUpAppCompatButton);




        mAppCompatButton.setOnClickListener(new View.OnClickListener() {



            @Override
            public void onClick(View view) {
                String email=emailEditText.getText().toString().trim();
                String password=passwordEditText.getText().toString().trim();
                mFirebaseAuth.createUserWithEmailAndPassword(email,password).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(SignUpActivity.this,e.getMessage().toString(),Toast.LENGTH_SHORT).show();

                    }
                }).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful())
                        {
                            startActivity(new Intent(SignUpActivity.this,LoginActivity.class));
                        }
                        else {
                            Toast.makeText(SignUpActivity.this,"Sign up failed",Toast.LENGTH_SHORT).show();
                        }

                    }
                });

            }
        });





    }
}
