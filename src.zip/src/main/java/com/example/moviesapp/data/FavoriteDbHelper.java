package com.example.moviesapp.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class FavoriteDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "favorite.db";
    private static final int DATABASE_VERSION = 1;
    public static final String LOGTAG = "FAVORITE";
    SQLiteOpenHelper dbhelper;
    SQLiteDatabase db;


    public FavoriteDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }


    public void open() {
        Log.d(LOGTAG, "Database Opened");
        db = dbhelper.getWritableDatabase();
    }



    public void close() {
        Log.i(LOGTAG, "Database Closed");
        dbhelper.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        final String SQL_CREATE_FAVORITE_TABLE = "CREATE TABLE " +FavoriteContract.FavoriteEntry.TABLE_NAME+ "("+
                FavoriteContract.FavoriteEntry._ID+"INTEGER PRIMARY KEY AUTOINCREMENT," +
                FavoriteContract.FavoriteEntry.COLUMN_MOVIEID+ "INTEGER,"+
                FavoriteContract.FavoriteEntry.COLUMN_TITLE+ "TEXT NOT NULL,"+
                FavoriteContract.FavoriteEntry.COLUMN_USER_RATING+ "REAL NOT NULL,"+
                FavoriteContract.FavoriteEntry.COLUMN_POSTER_PATH+ "TEXT NOT NULL,"+
                FavoriteContract.FavoriteEntry.COLUMN_PLOT_SYNOPSIS+ "TEXT NOT NULL,"+
                ");";
        sqLiteDatabase.execSQL(SQL_CREATE_FAVORITE_TABLE);
    }
}

