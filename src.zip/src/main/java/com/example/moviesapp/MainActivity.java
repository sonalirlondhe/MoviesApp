package com.example.moviesapp;

import android.content.Intent;
import android.os.Bundle;

import com.example.moviesapp.fragments.Main_Fragment;

import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;

public class MainActivity extends AppCompatActivity{
         Toolbar mToolbar;
         FirebaseAuth mFirebaseAuth;
         FirebaseUser mFirebaseUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mToolbar = findViewById(R.id.toolbar);
        mFirebaseAuth=FirebaseAuth.getInstance();
        mFirebaseUser=mFirebaseAuth.getCurrentUser();
        if(mFirebaseUser==null){
            startActivity(new Intent(MainActivity.this,LoginActivity.class));
        }

        mToolbar.setTitle(R.string.app_name);
        mToolbar.setNavigationIcon(R.drawable.logo);
        setSupportActionBar(mToolbar);
        getSupportFragmentManager().beginTransaction().add(R.id.frameLayout,new Main_Fragment()).commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.sort_order) {
            return false;
        }

        return super.onOptionsItemSelected(item);
    }


}
