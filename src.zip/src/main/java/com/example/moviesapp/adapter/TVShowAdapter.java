package com.example.moviesapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.moviesapp.TVShowDetailActivity;
import com.example.moviesapp.model.TVShow;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.moviesapp.R;

import java.util.List;

public class TVShowAdapter  extends RecyclerView.Adapter<TVShowAdapter.TVShowCustomViewHolder> {
    Context mcontext;
    List<TVShow> tvShowList;
    CardView cardView;


    public TVShowAdapter(Context mcontext, List<TVShow> tvShowList) {
        this.mcontext = mcontext;
        this.tvShowList = tvShowList;

    }

    @NonNull
    @Override
    public TVShowCustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_cardview_format, parent, false);
        return new TVShowCustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TVShowCustomViewHolder holder, int i) {
        Glide.with(mcontext).load(tvShowList.get(i).getPoster_path()).placeholder(R.drawable.load).into(holder.mcenterImageView);
        holder.mshowTitleTextView.setText(tvShowList.get(i).getOriginal_name());
        holder.mshowLanguageTextView.setText(tvShowList.get(i).getLanguage());
        String vote = Integer.toString(tvShowList.get(i).getVote_count());
        holder.mvotesTextView.setText(vote);
        holder.mreleaseYearTextView.setText(tvShowList.get(i).getFirst_air_date());
        String rating = Double.toString(tvShowList.get(i).getAverage_vote());
        holder.mratingTextView.setText(rating);
    }

    @Override
    public int getItemCount() {
        return tvShowList.size();
    }


    public class TVShowCustomViewHolder extends RecyclerView.ViewHolder {
        public ImageView mcenterImageView;
        public TextView mratingTextView, mreleaseYearTextView, mshowTitleTextView, mshowLanguageTextView, mvotesTextView;

        public TVShowCustomViewHolder(View itemView) {
            super(itemView);
            mcenterImageView = itemView.findViewById(R.id.centerImageView);
            mratingTextView = itemView.findViewById(R.id.ratingTextView);
            mreleaseYearTextView = itemView.findViewById(R.id.releaseYearTextView);
            mshowTitleTextView = itemView.findViewById(R.id.movieTitleTextView);
            mshowLanguageTextView = itemView.findViewById(R.id.movieTypeTextView);
            mvotesTextView = itemView.findViewById(R.id.votesTextView);
            cardView = itemView.findViewById(R.id.cardView);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        TVShow clickedDataItem = tvShowList.get(pos);
                        Intent intent = new Intent(mcontext, TVShowDetailActivity.class);
                        intent.putExtra("original_name", tvShowList.get(pos).getOriginal_name());
                        intent.putExtra("poster_path", tvShowList.get(pos).getPoster_path());
                        intent.putExtra("overview", tvShowList.get(pos).getOverview());
                        intent.putExtra("vote_average", Double.toString(tvShowList.get(pos).getAverage_vote()));
                        intent.putExtra("first_air_date", tvShowList.get(pos).getFirst_air_date());
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        mcontext.startActivity(intent);
                        Toast.makeText(v.getContext(), "You clicked " + clickedDataItem.getOriginal_name(), Toast.LENGTH_SHORT).show();


                    }
                }
            });


        }


    }
}

