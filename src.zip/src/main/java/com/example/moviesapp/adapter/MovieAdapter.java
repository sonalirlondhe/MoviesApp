package com.example.moviesapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.moviesapp.DetailActivity;
import com.example.moviesapp.R;
import com.example.moviesapp.model.Movie;

import java.util.List;


public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieCustomViewHolder> {

    Context mcontext;
    List<Movie> movieList;

    public MovieAdapter(Context mcontext, List<Movie> movieList) {
        this.mcontext = mcontext;
        this.movieList = movieList;
    }

    @NonNull
    @Override
    public MovieCustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.movie_cardview_format, parent, false);
        return new MovieCustomViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieCustomViewHolder holder, int i) {
        Glide.with(mcontext).load(movieList.get(i).getPosterPath()).placeholder(R.drawable.load).into(holder.mcenterImageView);
        holder.mmovieTitleTextView.setText(movieList.get(i).getOriginal_title());
        holder.mmovieTypeTextView.setText(movieList.get(i).getOriginal_Language());
        String vote = Integer.toString(movieList.get(i).getVoteCount());
        holder.mvotesTextView.setText(vote);
        holder.mreleaseYearTextView.setText(movieList.get(i).getReleaseDate());
        String rating = Double.toString(movieList.get(i).getVoteAverage());
        holder.mratingTextView.setText(rating);

    }

    @Override
    public int getItemCount() {
        return movieList.size();

    }

    public  class MovieCustomViewHolder extends RecyclerView.ViewHolder  {
        public ImageView mcenterImageView;
        public TextView mratingTextView;
        public TextView mreleaseYearTextView;
        public TextView mmovieTitleTextView;
        public TextView mmovieTypeTextView;
        public TextView mvotesTextView;
        public CardView cardView;


        public MovieCustomViewHolder(@NonNull View itemView) {
            super(itemView);
            mcenterImageView = itemView.findViewById(R.id.centerImageView);
            mratingTextView = itemView.findViewById(R.id.ratingTextView);
            mreleaseYearTextView = itemView.findViewById(R.id.releaseYearTextView);
            mmovieTitleTextView = itemView.findViewById(R.id.movieTitleTextView);
            mmovieTypeTextView = itemView.findViewById(R.id.movieTypeTextView);
            mvotesTextView = itemView.findViewById(R.id.votesTextView);
            cardView=itemView.findViewById(R.id.cardView);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
               public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        Movie clickedDataItem = movieList.get(pos);
                        Intent intent = new Intent(mcontext, DetailActivity.class);
                       intent.putExtra("original_title", movieList.get(pos).getOriginal_title());
                       intent.putExtra("poster_path", movieList.get(pos).getPosterPath());
                       intent.putExtra("overview", movieList.get(pos).getOverview());
                      intent.putExtra("vote_average", Double.toString(movieList.get(pos).getVoteAverage()));
                      intent.putExtra("release_date", movieList.get(pos).getReleaseDate());
                      intent.putExtra("id",movieList.get(pos).getId());
                       intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        mcontext.startActivity(intent);
                        Toast.makeText(v.getContext(), "You clicked " + clickedDataItem.getOriginal_title(), Toast.LENGTH_SHORT).show();


                    }
                }
            });


    }
}
}
