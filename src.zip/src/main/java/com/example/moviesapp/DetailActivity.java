package com.example.moviesapp;

        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.os.Bundle;
        import android.util.Log;
        import android.widget.ImageView;
        import android.widget.TextView;
        import android.widget.Toast;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.appcompat.widget.Toolbar;
        import androidx.preference.PreferenceManager;
        import androidx.recyclerview.widget.LinearLayoutManager;
        import androidx.recyclerview.widget.RecyclerView;

        import com.bumptech.glide.Glide;
        import com.example.moviesapp.adapter.TrailerAdapter;
        import com.example.moviesapp.api.Client;
        import com.example.moviesapp.api.Service;
        import com.example.moviesapp.model.Trailer;
        import com.example.moviesapp.model.TrailerResponse;
        import com.github.ivbaranov.mfb.MaterialFavoriteButton;
        import com.google.android.material.appbar.AppBarLayout;
        import com.google.android.material.appbar.CollapsingToolbarLayout;
        import com.google.android.material.snackbar.Snackbar;

        import java.util.ArrayList;
        import java.util.List;

        import retrofit2.Call;
        import retrofit2.Callback;
        import retrofit2.Response;


public class DetailActivity extends AppCompatActivity {
    TextView nameOfMovie,plotSynopsis,userRating,releaseDate;
    ImageView imageView;
    private RecyclerView recyclerView;
    private TrailerAdapter adapter;
    private List<Trailer> trailerList;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Toolbar toolbar=findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initCollapsingToolbar();

        imageView=findViewById(R.id.detail_activity_center_image_picture);
        nameOfMovie=findViewById(R.id.title);
        plotSynopsis=findViewById(R.id.plot_synopsis);
        userRating=findViewById(R.id.user_rating);
        releaseDate=findViewById(R.id.release_date);
        Intent intentThatStartedThisActivity=getIntent();
        if (intentThatStartedThisActivity.hasExtra("original_title")) {
            String thumbnail = getIntent().getExtras().getString("poster_path");
            String movieName = getIntent().getExtras().getString("original_title");
            String synopsis = getIntent().getExtras().getString("overview");
            String rating = getIntent().getExtras().getString("vote_average");
            String dateOfRelease = getIntent().getExtras().getString("release_date");


            Glide.with(this).load(thumbnail).placeholder(R.drawable.load).into(imageView);

            nameOfMovie.setText(movieName);
            plotSynopsis.setText(synopsis);
            userRating.setText(rating);
            releaseDate.setText(dateOfRelease);
        }
        else
        {
            Toast.makeText(this,"No API Data",Toast.LENGTH_SHORT).show();
        }
        MaterialFavoriteButton materialFavoriteButton;
        materialFavoriteButton=findViewById(R.id.favorite_button);
        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        materialFavoriteButton.setOnFavoriteChangeListener(new MaterialFavoriteButton.OnFavoriteChangeListener() {
            @Override
            public void onFavoriteChanged(MaterialFavoriteButton buttonView, boolean favorite) {
                if (favorite) {
                    SharedPreferences.Editor editor = getSharedPreferences("com.example.moviesapp.DetailActivity", MODE_PRIVATE).edit();
                    editor.putBoolean("Favorite Added ",true);
                    editor.commit();
                    Snackbar.make(buttonView,"Added to Favorite",Snackbar.LENGTH_SHORT).show();;

                }else{
                    SharedPreferences.Editor editor = getSharedPreferences("com.example.moviesapp.DetailActivity", MODE_PRIVATE).edit();
                    editor.putBoolean("Favorite Removed ",true);
                    editor.commit();
                    Snackbar.make(buttonView,"Removed from Favorite",Snackbar.LENGTH_SHORT).show();
                }

            }
        });
       initViews();

    }
    private  void  initCollapsingToolbar(){
        final CollapsingToolbarLayout collapsingToolbarLayout=findViewById(R.id.collapsingToolBar1);
        collapsingToolbarLayout.setTitle(" ");

        AppBarLayout appBarLayout=findViewById(R.id.appbar1);
        appBarLayout.setExpanded(true);

        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow=false;
            int scrollRange=-1;
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffSet) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                if (scrollRange + verticalOffSet == 0) {
                    collapsingToolbarLayout.setTitle(getString(R.string.movie_details));
                    isShow = true;
                }else  if (isShow){
                    collapsingToolbarLayout.setTitle(" ");
                    isShow=false;
                }

            }
        });
    }

    private void initViews() {
        trailerList = new ArrayList<>();
        adapter = new TrailerAdapter(this, trailerList);
        recyclerView = findViewById(R.id.recycler_view1);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        loadJSON();
    }

    private void loadJSON() {
        int movie_id =getIntent().getExtras().getInt("id");
        try {
            if (BuildConfig.THE_MOVIE_DB_API_TOKEN.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please obtain API key from themoviedb.org", Toast.LENGTH_SHORT).show();
                return;
            }
            Client client = new Client();
            Service apiService = client.getClient().create(Service.class);
            Call<TrailerResponse> call = apiService.getMovieTrailer(movie_id, BuildConfig.THE_MOVIE_DB_API_TOKEN);
            call.enqueue(new Callback<TrailerResponse>() {
                @Override
                public void onResponse(Call<TrailerResponse> call, Response<TrailerResponse> response) {
                    List<Trailer> trailer = response.body().getResults();
                    recyclerView.setAdapter(new TrailerAdapter(getApplicationContext(), trailer));
                    recyclerView.smoothScrollToPosition(0);
                }


                @Override
                public void onFailure(Call<TrailerResponse> call, Throwable t) {
                    Log.d("Error", t.getMessage());
                    Toast.makeText(DetailActivity.this, "Error fetching trailer data!", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception e) {
            Log.d("Error", e.getMessage());
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }
    }





}
