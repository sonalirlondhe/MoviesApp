package com.example.moviesapp.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TVShow {
    @SerializedName("original_name")
    private  String original_name;
    @SerializedName("genre_ids")
    private List<Integer> genres_ids;
    @SerializedName("vote_count")
    private Integer vote_count;
    @SerializedName("first_air_date")
    private String  first_air_date;
    @SerializedName("name")
    private String name;
    @SerializedName("vote_average")
    private Double average_vote;
    @SerializedName("overview")
    private String overview;
    @SerializedName("poster_path")
    private String poster_path;
    @SerializedName("popularity")
    private Double popularity;
    @SerializedName("original_language")
    private String language;

    public TVShow(String original_name, List<Integer> genres_ids, Integer vote_count, String first_air_date, String name, Double average_vote
    , String overview, String poster_path, Double popularity, String language){
        this.original_name=original_name;
        this.genres_ids=genres_ids;
        this.vote_count=vote_count;
        this.first_air_date=first_air_date;
        this.name=name;
        this.average_vote=average_vote;
        this.overview=overview;
        this.poster_path=poster_path;
        this.popularity=popularity;
        this.language=language;
    }

    public String getOriginal_name() {
        return original_name;
    }

    public void setOriginal_name(String original_name) {
        this.original_name = original_name;
    }

    public List<Integer> getGenres_ids() {
        return genres_ids;
    }

    public void setGenres_ids(List<Integer> genres_ids) {
        this.genres_ids = genres_ids;
    }

    public Integer getVote_count() {
        return vote_count;
    }

    public void setVote_count(Integer vote_count) {
        this.vote_count = vote_count;
    }

    public String getFirst_air_date() {
        return first_air_date;
    }

    public void setFirst_air_date(String first_air_date) {
        this.first_air_date = first_air_date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getAverage_vote() {
        return average_vote;
    }

    public void setAverage_vote(Double average_vote) {
        this.average_vote = average_vote;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getPoster_path() {
        return "https://image.tmdb.org/t/p/w500"+poster_path;
    }

    public void setPoste_path(String poste_path) {
        this.poster_path = poste_path;
    }

    public Double getPopularity() {
        return popularity;
    }

    public void setPopularity(Double popularity) {
        this.popularity = popularity;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }








}
