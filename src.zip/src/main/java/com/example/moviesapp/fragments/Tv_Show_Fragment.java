package com.example.moviesapp.fragments;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.example.moviesapp.BuildConfig;
import com.example.moviesapp.R;
import com.example.moviesapp.SettingsActivity;
import com.example.moviesapp.adapter.TVShowAdapter;
import com.example.moviesapp.api.Client;
import com.example.moviesapp.api.Service;
import com.example.moviesapp.model.TVShow;
import com.example.moviesapp.model.TVShowResponse;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Tv_Show_Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Tv_Show_Fragment extends Fragment implements SharedPreferences.OnSharedPreferenceChangeListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private RecyclerView mRecyclerView;
    private TVShowAdapter tvShowAdapter;
    private List<TVShow> tvShowList;
    private FrameLayout frameLayout;
    ProgressDialog pd;
    public static final String LOG_TAG=TVShowAdapter.class.getName();


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;


    public Tv_Show_Fragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Tv_Show_Fragment.
     */
    // TODO: Rename and change types and number of parameters
    public static Tv_Show_Fragment newInstance(String param1, String param2) {
        Tv_Show_Fragment fragment = new Tv_Show_Fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tv__show_, container, false);
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initView();
        frameLayout=getActivity().findViewById(R.id.frameLayout);
    }


    @Nullable
    @Override
    public Context getContext() {
        Context context = this.getActivity();

        while (context instanceof ContextWrapper) {
            if (context instanceof FragmentActivity) {
                return (FragmentActivity) context;
            }
            context = ((ContextWrapper) context).getBaseContext();
        }
        return null;

    }

    private  void initView()
    {
        pd=new ProgressDialog(this.getActivity());
        pd.setMessage("Fetching Data...");
        pd.setCancelable(false);
        pd.show();

        mRecyclerView = getView().findViewById(R.id.tvShowFragmentRecyclerView);
        tvShowList = new ArrayList<TVShow>();
        tvShowAdapter = new TVShowAdapter(getContext(), tvShowList);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(tvShowAdapter);
        tvShowAdapter.notifyDataSetChanged();
        checkSortOrder();
    }


    private void loadJSON(){
        try{

            if (BuildConfig.THE_MOVIE_DB_API_TOKEN.isEmpty()){
                Toast.makeText(getContext(),"Please obtain API KEY from themoviesdb.org",Toast.LENGTH_SHORT).show();
                pd.dismiss();
                return;

            }
            Client client=new Client();
            Service apiService=client.getClient().create(Service.class);
            Call<TVShowResponse> call=apiService.getPopularTVShows(BuildConfig.THE_MOVIE_DB_API_TOKEN);
            call.enqueue(new Callback<TVShowResponse>() {
                @Override
                public void onResponse(Call<TVShowResponse> call, Response<TVShowResponse> response) {
                    List<TVShow> tvShowList=response.body().getResults();
                    mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

                    mRecyclerView.setAdapter(new TVShowAdapter(getContext(), tvShowList));
                    mRecyclerView.smoothScrollToPosition(0);
                    pd.dismiss();

                }

                @Override
                public void onFailure(Call<TVShowResponse> call, Throwable t) {
                    Log.d("Error",t.getMessage());
                    Toast.makeText(getContext(),"Error fetching  data",Toast.LENGTH_SHORT).show();
                }
            });
        }
        catch (Exception e){
            Log.d("Error",e.getMessage());
            Toast.makeText(getContext(),e.toString(),Toast.LENGTH_SHORT).show();
        }

    }


    private void loadJSON1(){
        try{

            if (BuildConfig.THE_MOVIE_DB_API_TOKEN.isEmpty()){
                Toast.makeText(getContext(),"Please obtain API KEY from themoviesdb.org",Toast.LENGTH_SHORT).show();
                pd.dismiss();
                return;
            }
            Client client=new Client();
            Service apiService=client.getClient().create(Service.class);
            Call<TVShowResponse> call=apiService.getTopRatedTVShows(BuildConfig.THE_MOVIE_DB_API_TOKEN);
            call.enqueue(new Callback<TVShowResponse>() {
                @Override
                public void onResponse(Call<TVShowResponse> call, Response<TVShowResponse> response) {
                    List<TVShow> tvShowList=response.body().getResults();
                    mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

                    mRecyclerView.setAdapter(new TVShowAdapter(getContext(),tvShowList));
                    mRecyclerView.smoothScrollToPosition(0);
                    pd.dismiss();
                }

                @Override
                public void onFailure(Call<TVShowResponse> call, Throwable t) {
                    Log.d("Error",t.getMessage());
                    Toast.makeText(getContext(),"Error fetching movies data",Toast.LENGTH_SHORT).show();
                }
            });
        }
        catch (Exception e){
            Log.d("Error",e.getMessage());
            Toast.makeText(getContext(),e.toString(),Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        Log.d(LOG_TAG,"Preference updated");
        checkSortOrder();
    }
    private  void checkSortOrder(){
        SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(getContext());
        String sortOrder=preferences.getString(
                this.getActivity().getString(R.string.sort_order_key),
                this.getActivity().getString(R.string.most_popular));

        if (sortOrder.equals(getString(R.string.most_popular))){
            Log.d(LOG_TAG,"Sorting by most popular");
            loadJSON();


        }else{
            Log.d(LOG_TAG,"Sorting by high rated");
            loadJSON1();

        }


    }
    @Override
    public  void onResume(){
        super.onResume();
        if (tvShowList.isEmpty()){
            checkSortOrder();
        }else {

        }
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.sort_order:
                Intent intent=new Intent(getContext(), SettingsActivity.class);
                startActivity(intent);
                return true;
            default:return super.onOptionsItemSelected(item);
        }
    }


}
