package com.example.moviesapp.fragments;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.moviesapp.BuildConfig;
import com.example.moviesapp.DetailActivity;
import com.example.moviesapp.MainActivity;
import com.example.moviesapp.R;
import com.example.moviesapp.SettingsActivity;
import com.example.moviesapp.adapter.MovieAdapter;
import com.example.moviesapp.adapter.TVShowAdapter;
import com.example.moviesapp.api.Client;
import com.example.moviesapp.api.Service;
import com.example.moviesapp.model.Movie;
import com.example.moviesapp.model.MovieResponse;
import com.example.moviesapp.model.TVShow;
import com.example.moviesapp.model.TVShowResponse;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Movie_Fragments#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Movie_Fragments extends Fragment implements SharedPreferences.OnSharedPreferenceChangeListener {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private RecyclerView mRecyclerView;
    private MovieAdapter movieAdapter;
    private List<Movie>  movieList;
    private ProgressDialog pd;
    public static final String LOG_TAG=MovieAdapter.class.getName();




    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;


    public Movie_Fragments() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Movie_Fragments.
     */
    // TODO: Rename and change types and number of parameters
    public static Movie_Fragments newInstance(String param1, String param2) {
        Movie_Fragments fragment = new Movie_Fragments();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_movie__fragments, container, false);
    }


    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        final Activity context=getActivity();

        mRecyclerView=getView().findViewById(R.id.movieFragmentRecyclerView);
        movieList=new ArrayList<Movie>();
        pd=new ProgressDialog(getContext());
        movieAdapter =new MovieAdapter(getContext(),movieList);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        mRecyclerView.setAdapter(movieAdapter);
        movieAdapter.notifyDataSetChanged();

          checkSortOrder();


    }

   private void loadJSON(){
        try{
            pd.setMessage("Fetching data.......");
            pd.setCancelable(false);
            pd.show();
            if (BuildConfig.THE_MOVIE_DB_API_TOKEN.isEmpty()){
                Toast.makeText(getContext(),"Please obtain API KEY from themoviesdb.org",Toast.LENGTH_SHORT).show();
                pd.dismiss();
                return;
            }
            Client client=new Client();
            Service apiService=client.getClient().create(Service.class);
            Call<MovieResponse> call=apiService.getPopularMovies(BuildConfig.THE_MOVIE_DB_API_TOKEN);
            call.enqueue(new Callback<MovieResponse>() {
                @Override
                public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                List<Movie> movieList=response.body().getResults();
                mRecyclerView.setAdapter(new MovieAdapter(getContext(),movieList));
                mRecyclerView.smoothScrollToPosition(0);
                pd.dismiss();
                }

                @Override
                public void onFailure(Call<MovieResponse> call, Throwable t) {
                    Log.d("Error",t.getMessage());
                 Toast.makeText(getContext(),"Error fetching data",Toast.LENGTH_SHORT).show();
                }
            });
        }
        catch (Exception e){
            Log.d("Error",e.getMessage());
            Toast.makeText(getContext(),e.toString(),Toast.LENGTH_SHORT).show();
        }

    }
    private void loadJSON1(){
        try{
            pd.setMessage("Fetching data.......");
            pd.setCancelable(false);
            pd.show();
            if (BuildConfig.THE_MOVIE_DB_API_TOKEN.isEmpty()){
                Toast.makeText(getContext(),"Please obtain API KEY from themoviesdb.org",Toast.LENGTH_SHORT).show();
                pd.dismiss();
                return;
            }
            Client client=new Client();
            Service apiService=client.getClient().create(Service.class);
            Call<MovieResponse> call=apiService.getTopRatedMovies(BuildConfig.THE_MOVIE_DB_API_TOKEN);
            call.enqueue(new Callback<MovieResponse>() {
                @Override
                public void onResponse(Call<MovieResponse> call, Response<MovieResponse> response) {
                    List<Movie> movieList=response.body().getResults();
                    mRecyclerView.setAdapter(new MovieAdapter(getContext(),movieList));
                    mRecyclerView.smoothScrollToPosition(0);
                    pd.dismiss();
                }

                @Override
                public void onFailure(Call<MovieResponse> call, Throwable t) {
                    Log.d("Error",t.getMessage());
                    Toast.makeText(getContext(),"Error fetching data",Toast.LENGTH_SHORT).show();
                }
            });
        }
        catch (Exception e){
            Log.d("Error",e.getMessage());
            Toast.makeText(getContext(),e.toString(),Toast.LENGTH_SHORT).show();
        }

    }
    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String s) {
        Log.d(LOG_TAG,"Preference updated");
        checkSortOrder();
    }
    private  void checkSortOrder(){
  SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(this.getActivity());
  String sortOrder=preferences.getString(
          this.getActivity().getString(R.string.sort_order_key),
          this.getActivity().getString(R.string.most_popular));

     if (sortOrder.equals(getString(R.string.most_popular))){
       Log.d(LOG_TAG,"Sorting by most popular");
       loadJSON();

     }else{
         Log.d(LOG_TAG,"Sorting by high rated");
         loadJSON1();

     }

    }
    @Override
    public  void onResume() {
        super.onResume();
        if (movieList.isEmpty()) {
            checkSortOrder();
        } else {

        }
    }




    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.sort_order:
                Intent intent=new Intent(this.getActivity(),SettingsActivity.class);
                startActivity(intent);
                return true;
            default:return super.onOptionsItemSelected(item);
        }
    }
}
