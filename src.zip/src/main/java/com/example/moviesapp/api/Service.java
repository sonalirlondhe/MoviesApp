package com.example.moviesapp.api;
import com.example.moviesapp.adapter.TrailerAdapter;
import com.example.moviesapp.model.MovieResponse;
import com.example.moviesapp.model.TVShowResponse;
import com.example.moviesapp.model.TrailerResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Service {

    @GET("movie/popular")
    Call<MovieResponse> getPopularMovies(@Query("api_key") String apikey);

    @GET("movie/top_rated")
    Call<MovieResponse> getTopRatedMovies(@Query("api_key") String apikey);

    @GET("movie/{movie_id}/videos")
    Call<TrailerResponse> getMovieTrailer(@Path("movie_id")int id, @Query("api_key") String apikey);

    @GET("tv/popular")
    Call<TVShowResponse> getPopularTVShows(@Query("api_key") String apikey);
    @GET("tv/top_rated")
    Call<TVShowResponse> getTopRatedTVShows(@Query("api_key") String apikey);


}
